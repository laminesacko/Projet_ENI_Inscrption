import 'package:flutter/material.dart';
import 'package:mini_projet_debut/login.dart';

class Initialisation extends StatefulWidget {
  const Initialisation({super.key});

  @override
  State<Initialisation> createState() => _InitialisationState();
}

class _InitialisationState extends State<Initialisation> {

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(future: Future.delayed(const Duration(seconds: 3)), builder: (context, snapshot){
      if(snapshot.connectionState==ConnectionState.waiting){return afficherImage();}
      return Login();
    });
    
  }
   Widget afficherImage() {
    return  Scaffold(
      backgroundColor: Colors.white, // Couleur de fond
      body: Center(
        child: Image.asset('Assets/ENI_ABT.jpg'),
      ),
    );// Image depuis les assets
  }
}